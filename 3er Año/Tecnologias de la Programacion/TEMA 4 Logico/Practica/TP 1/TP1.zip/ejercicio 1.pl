% Conteste que retornarán las consultas abajo dado el siguiente cuerpo de conocimiento:
 f(a, 2).
 f(a, 3).
 f(b, 2).
 f(b, 4).
 f(c, 1).
 f(c, 2).
 men(nico).
%a. f(X, 1).
%b. f(X).
%c. f(a, X).
%d. f(c, 1).
%e. f(X, Y).
%f. f(2, a).
%g. f(X, Y), f(X, 4).
