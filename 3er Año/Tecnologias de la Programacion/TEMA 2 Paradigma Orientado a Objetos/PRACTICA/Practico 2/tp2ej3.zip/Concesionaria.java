package tp2ej3;

import java.util.Vector;

public class Concesionaria {
	
	 private String nombre;	
	 private Vector<Vehiculo>myVehiculo;
	 private Vector<Venta>myVenta;
 
  public Concesionaria(String nombre, Vector<Vehiculo> myVehiculo, Vector<Venta> myVenta) {
	super();
	this.nombre = nombre;
	this.myVehiculo = myVehiculo;
	this.myVenta = myVenta;
}
 
public float mostrarTotalVentaAutosNacionalesConDue�o() {
	
	float totalSumatoriaVentas=0f;
	
	for (Venta oVenta: myVenta) {
		
		if(oVenta.esVentaAuto()==true) {
			totalSumatoriaVentas+=oVenta.CalcularTotalDetalles();
		}
	}
	
	return totalSumatoriaVentas;
}

}