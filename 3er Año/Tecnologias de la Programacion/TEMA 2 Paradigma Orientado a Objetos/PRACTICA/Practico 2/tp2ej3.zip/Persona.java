package tp2ej3;

public class Persona {

public String apellido;
public String nombre;
	
  
  public Persona(String apellido, String nombre) {
		super();
		this.apellido = apellido;
		this.nombre = nombre;
	}


      
}