package tp2ej3;

public class Pais {

private String nombre;
private Float arancel;

  public Pais(String nombre,Float arancel) {
		super();
		this.nombre = nombre;
		this.arancel=arancel;
	}

public String mostrarPais() {
	return this.nombre;
}

  public boolean esNacional() {
	  if(this.nombre=="Argentina") {
		  return true;
	  }else {
		  return false;
	  }
  }


}