package tp2ej3;

public class Due�o {


  public Integer telefono;

  public Persona myPersona;
    
    public Due�o(Integer telefono, Persona myPersona) {
  		super();
  		this.telefono = telefono;
  		this.myPersona = myPersona;
  	}

  
}