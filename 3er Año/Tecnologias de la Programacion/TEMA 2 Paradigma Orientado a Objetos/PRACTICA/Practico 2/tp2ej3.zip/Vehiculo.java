package tp2ej3;

import java.util.Vector;

public abstract class Vehiculo {

  private String marca;
  private Integer modelo;
  private String patente;
  private Float precio;
  private Integer kilometraje;
  private Due�o myDue�o;

  
  
  
  public Vehiculo(String marca, Integer modelo, String patente, Float precio, Integer kilometraje, 
		  Due�o myDue�o) {
		super();
		this.marca = marca;
		this.modelo = modelo;
		this.patente = patente;
		this.precio = precio;
		this.kilometraje = kilometraje;
		this.myDue�o = myDue�o;
		
	}
  
  
public abstract Boolean esAuto();
public abstract Boolean esNacional();


public boolean tieneDue�o() {
	
	if(this.myDue�o==null) {
		return false;
	}else {
		return true;
	}
}

}