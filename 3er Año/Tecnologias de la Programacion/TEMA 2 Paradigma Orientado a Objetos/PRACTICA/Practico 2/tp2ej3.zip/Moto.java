package tp2ej3;

public class Moto extends Vehiculo {

	public Moto(String marca, Integer modelo, String patente, Float precio, Integer kilometraje,
			Due�o myDue�o) {
		super(marca, modelo, patente, precio, kilometraje, myDue�o);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Boolean esAuto() {
		return false;
	}

	@Override
	public Boolean esNacional() {
		// TODO Auto-generated method stub
		return null;
	}


}