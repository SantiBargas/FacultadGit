package tp2ej3;

public class Auto extends Vehiculo {

	private Pais myPais;
	
    public Auto(String marca, Integer modelo, String patente, Float precio, Integer kilometraje, Due�o myDue�o,
			Pais myPais) {
		super(marca, modelo, patente, precio, kilometraje, myDue�o);
		this.myPais = myPais;
	}

	

	@Override
	public Boolean esAuto() {
		return true;
	}

	public Boolean esNacional() {
		if(this.myPais.mostrarPais()=="Argentina") {
			return true;
		}
		else {
			return false;
		}
	}

}