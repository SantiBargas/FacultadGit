package tp2ej3;

public class Comprador { 

public Integer dni;

public Persona myPersona;


public Comprador(Integer dni, Persona myPersona) {
	super();
	this.dni = dni;
	this.myPersona = myPersona;
}

}