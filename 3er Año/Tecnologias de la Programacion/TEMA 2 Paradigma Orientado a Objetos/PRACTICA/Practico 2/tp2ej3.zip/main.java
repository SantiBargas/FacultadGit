package tp2ej3;

import java.util.Calendar;
import java.util.Vector;

public class main {

	public static void main(String[] args) {
		
		
		/*ACLARACION: Que un vehiculo tenga un due�o null significa
		 * que no tiene due�o*/
		 
		
		
		Calendar fecha = Calendar.getInstance();
		Pais Argentina = new Pais("Argentina",0f);
		Pais Holanda = new Pais("Holanda",20f);
		
		Persona APersona = new Persona("Bargas","Santiago");
		Persona BPersona = new Persona("Molas","Tomas");
		Persona CPersona = new Persona("Mari�o","Pablo");
		Persona DPersona = new Persona("Flores","Tomas");
		Persona EPersona = new Persona("Grippo","Tomas");
		Persona FPersona = new Persona("Telli","Tomas");
		
		Due�o ADue�o = new Due�o(4243260,APersona);
		Due�o BDue�o = new Due�o(4243260,BPersona);
		Due�o CDue�o = new Due�o(4243260,CPersona);
		
		Comprador AComprador = new Comprador(4243260,DPersona);
		Comprador BComprador = new Comprador(4243260,EPersona);
		Comprador CComprador = new Comprador(4243260,FPersona);
		
		Due�o DUE�ONULL= null;
		
		
		Auto AAuto = new Auto("Chevrolet",242,"ABC 212",5000f,20,ADue�o,Argentina);
		Auto BAuto = new Auto("Mercedes",242,"ABC 212",5000f,20,BDue�o,Argentina);
		Auto CAuto = new Auto("Renault",242,"ABC 212",5000f,20,DUE�ONULL,Holanda);
		Moto AMoto = new Moto("Chevrolet",242,"ABC 212",5000f,20,DUE�ONULL);
		Camioneta ACamioneta = new Camioneta("Chevrolet",242,"ABC 212",5000f,20,DUE�ONULL);
		
		Vector<Vehiculo> vectorVehiculo = new Vector<Vehiculo>();
		vectorVehiculo.add(ACamioneta);
		vectorVehiculo.add(AMoto);
		vectorVehiculo.add(AAuto);
		vectorVehiculo.add(BAuto);
		vectorVehiculo.add(CAuto);
		
	
		//VENTA 1 DEBE SUMAR
		detalleVenta ADetalle= new detalleVenta(5000f,fecha,AAuto);
		Vector<detalleVenta> vectorDet1 = new Vector<detalleVenta>();
		vectorDet1.add(ADetalle);		
		Venta AVenta = new Venta(vectorDet1,AComprador);
		

		//VENTA 2 DEBE SUMAR
		detalleVenta BDetalle= new detalleVenta(5000f,fecha,BAuto);
		detalleVenta CDetalle= new detalleVenta(5000f,fecha,CAuto);
		Vector<detalleVenta> vectorDet2 = new Vector<detalleVenta>();
		vectorDet2.add(BDetalle);		
		vectorDet2.add(CDetalle);
		Venta BVenta = new Venta(vectorDet2,AComprador);
		
		//VENTA 3 NO DEBE SUMAR
		detalleVenta DDetalle= new detalleVenta(5000f,fecha,CAuto);
		Vector<detalleVenta> vectorDet3 = new Vector<detalleVenta>();
		vectorDet3.add(DDetalle);
		Venta CVenta = new Venta(vectorDet3,AComprador);
		
		
		Vector<Venta> vectorVenta = new Vector<Venta>();
		vectorVenta.add(AVenta);
		vectorVenta.add(BVenta);
		vectorVenta.add(CVenta);
		Concesionaria AConcesionaria = new Concesionaria("TODO MOTORES",vectorVehiculo,vectorVenta);
		
		System.out.println(AConcesionaria.mostrarTotalVentaAutosNacionalesConDue�o());
		
	}

}
