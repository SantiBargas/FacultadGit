package tp2ej3;

import java.util.Vector;

class Venta {

  
	private Vector<detalleVenta>  mydetalleVenta;
	  private Comprador myComprador;
	 
	
	public Venta(Vector<detalleVenta> mydetalleVenta, Comprador myComprador) {
		super();
		this.mydetalleVenta = mydetalleVenta;
		this.myComprador = myComprador;
	}


  public Boolean esVentaAuto() {
	  
	  for (detalleVenta odetVenta: mydetalleVenta) {
			if( odetVenta.esVentaAutoNacionalConDue�o()==true) {
				return true;
			}
			
		}
	  return false;
  }

 public Float CalcularTotalDetalles() {
	  
	  float totalDetalles=0f;
	  for (detalleVenta odetVenta: mydetalleVenta) {
		 System.out.println("TOTAL PRECIO DETALLE: "+odetVenta.getPrecio());
		totalDetalles+=odetVenta.getPrecio();
		
	  }
	  return totalDetalles;
  }
  
}