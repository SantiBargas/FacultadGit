package tp2ej3;

import java.util.Calendar;

public class detalleVenta {

	 private Float precio;

	 private Calendar fecha;

     private Vehiculo myVehiculo;

			public detalleVenta(Float precio, Calendar fecha, Vehiculo myVehiculo) {
				super();
				this.precio = precio;
				this.fecha = fecha;
				this.myVehiculo = myVehiculo;
			}

	public boolean esVentaAutoNacionalConDue�o() {
		
		boolean a=false;
		if(this.myVehiculo.esAuto()==true && this.myVehiculo.esNacional() == true &&
		   this.myVehiculo.tieneDue�o()==true) {
				a=true;
			}		
		return a;
	}

	public float getPrecio() {
		return this.precio;
	}
			
}