#include <SFML/Graphics.hpp>
#include "Game.h"
using namespace sf;

int main(int argc, char *argv[]){
	Game g;
	g.Run();
	return 0;
}

