#include "Scene.h"

Scene::Scene() {
	
}

