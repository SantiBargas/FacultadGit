#include <iostream>
#include <cmath>
using namespace std;

const double PI = 2*acos(0);

class Cilindro {
public:
	Cilindro();
	Cilindro(float radio, float altura);
	void AsignarDatos(float radio, float altura);
	float ObtenerVolumen();
private:
	float m_radio, m_altura;
};

Cilindro::Cilindro() { 
	m_radio = 0; m_altura = 0;
}

Cilindro::Cilindro(float radio, float altura) {
	m_radio = radio;
	m_altura = altura;
}

void Cilindro::AsignarDatos(float radio, float altura) {
	m_radio = radio;
	m_altura = altura;
}
float Cilindro::ObtenerVolumen() {
	return PI*m_radio*m_radio*m_altura;
}

int main() {	
	Cilindro c1, c2(5.3,10.2);
	float r, h;
	cin >> r >> h;
	c1.AsignarDatos(r,h);
	
	cout << "Vol de c1: " << c1.ObtenerVolumen() << endl;
	cout << "Vol de c2: " << c2.ObtenerVolumen() << endl;
	return 0;
}

