#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

class Polinomio {
	vector<float> m_coefs;
public:
	Polinomio(int grado) {
		m_coefs.resize(grado+1,0);
	}
	void CargarCoef(int i, int c) {
		m_coefs[i] = c;
	}
	float Evaluar(float x) {
		float sum = 0;
		for(size_t i=0;i<m_coefs.size();++i)
			sum += m_coefs[i]*pow(x,i);
		return sum;
	}
	int VerGrado() { return m_coefs.size()-1; }
	int VerCoef(size_t i) { 
		if (i<m_coefs.size()) return m_coefs[i]; 
		else return 0;
	}
	
	Polinomio Sumar(Polinomio p2) {
		int g; 
		if (this->VerGrado() > p2.VerGrado()) g = this->VerGrado();
		else g = p2.VerGrado();
		Polinomio ps( g );
		for(int i=0;i<=ps.VerGrado();++i)
			ps.CargarCoef(i, this->VerCoef(i)+p2.VerCoef(i) );
		return ps;
	}
	
};

int main() {
	
	Polinomio p1(2);      // 0*x^0 + 0*x^1 + 0*x^2
	p1.CargarCoef(0,3);  // 3*x^0 + 0*x^1 + 0*x^2
	p1.CargarCoef(2,1);  // 3*x^0 + 0*x^1 + 1*x^2
	
	Polinomio p2(4);
	p2.CargarCoef(1,1);
	p2.CargarCoef(4,5);
		
	Polinomio ps = p1.Sumar(p2);
	
	for(int i=0;i<=ps.VerGrado();++i) { 
		if (i!=0) cout << " + ";
		cout << ps.VerCoef(i) << "*x^" << i;
	}
	
	return 0;
}
