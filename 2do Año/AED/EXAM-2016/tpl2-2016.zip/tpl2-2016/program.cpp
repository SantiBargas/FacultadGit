#define USECHRONO
#include "eval.hpp"
#include <cassert>
#include <climits>
#include <cstdlib>
#include <stack>

using namespace aed;
using namespace std;

bool unordered_equal(tree<int> &A,tree<int> &B,
                     tree<int>::iterator itA,
                     tree<int>::iterator itB) {
  // COMPLETAR ....
  return false;
}

bool unordered_equal(tree<int> &A,tree<int> &B) {
  // COMPLETAR ....
  return false;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
bool hay_camino(map<string,list<string> > &M, string cini, string cfin, map<string,bool> visited) {
  // COMPLETAR ....
  return false;
}

bool hay_camino(map<string,list<string> > &M, list<string> &P, string cini, string cfin) {
  // COMPLETAR ....
  return false;
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void enhance_html(tree<string> &T, string father, tree<string>::iterator it) {
  // COMPLETAR ....
}

void enhance_html(tree<string> &T) {
  // COMPLETAR ....
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0;

  ev.eval<1>(unordered_equal,vrbs);
  h1 = ev.evalr<1>(unordered_equal,seed,vrbs);
  
  ev.eval<2>(hay_camino,vrbs);
  h2 = ev.evalr<2>(hay_camino,seed,vrbs);
  
  ev.eval<3>(enhance_html,vrbs);
  h3 = ev.evalr<3>(enhance_html,seed,vrbs);

  printf("S=%03d -> H1=%03d H2=%03d H3=%03d\n",
         seed,h1,h2,h3);
  
  return 0;
}
