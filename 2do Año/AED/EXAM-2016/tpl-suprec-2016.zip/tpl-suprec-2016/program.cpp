#define USECHRONO
#include <cassert>
#include <climits>
#include <cstdlib>
#include <stack>
#include <map>
#include <numeric>
#include "eval.hpp"

using namespace aed;
using namespace std;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

void filter_sets(list<set<int> > &LS_IN,
                 int (*func)(int), list<set<int> > &LS_OUT){
  // COMPLETAR....
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int distancia(map<int,list<int> >& G, int x, int y){
  // COMPLETAR....
  return 0;
}


//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void suma_en_la_hoja(tree<int>&T){
  // COMPLETAR....
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

int main() {
  
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0;

  cout << "seed: 123" << endl;
  do {
    ev.eval<1>(filter_sets,vrbs);
    h1 = ev.evalr<1>(filter_sets,seed,vrbs);
    
    ev.eval<2>(distancia,vrbs);
    h2 = ev.evalr<2>(distancia,seed,vrbs);
    
    ev.eval<3>(suma_en_la_hoja,vrbs);
    h3 = ev.evalr<3>(suma_en_la_hoja,seed,vrbs);
    
    printf("S=%03d -> H1=%03d H2=%03d H3=%03d\n",
           seed,h1,h2,h3);
    
    cout << endl << "Siguiente seed: ";
  } while (cin>>seed);

  return 0;
  
}
