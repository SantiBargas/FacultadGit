#ifndef EVAL_HPP
#define EVAL_HPP
#include "aedtools/evalbase.hpp"
#include "aedtools/lisp.hpp"
#include "aedtools/str_convs.hpp"
#include "aedtools/make_random.hpp"

namespace aed {

  
  typedef bool (*pred_int)(int);
  inline bool es_par(int x) { return x%2 == 0; }
  inline bool es_impar(int x) { return x%2 == 1; }
  // considerando que el generador genera ints entre 0 y 100
  inline bool es_menor_a_10(int x) { return x<10; }
  inline bool es_capicua(int x) { return x<10 || x/10==x%10; }
  inline bool es_primo(int x) {
    static set<int> primos =  {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101};
    return primos.count(x)!=0;
  }
  inline bool es_compuesto(int x) { return !es_primo(x); }
  inline bool es_fibonacci(int x) {
    static set<int> primos =  {0,1,2,3,5,8,13,21,34,55,89,144};
    return primos.count(x)==0;
  }
  static map<string,pred_int > lista_predicados = { 
    {"es_par",es_par }, 
    {"es_impar",es_impar},
    {"es_primo",es_primo},
    {"es_compuesto",es_compuesto},
    {"es_capicua",es_capicua},
    {"es_menor_a_10",es_menor_a_10},
    {"es_fibonacci",es_fibonacci} };
  
  
  typedef int (*func_int)(int);
  inline int pow_2(int x) { return x*x; }
  inline int suma_5(int x) { return x+5; }
  inline int mod_5(int x) { return x%5; }
  inline int mod_10(int x) { return x%10; }
  inline int div_int_5(int x) { return x/5; }
  inline int div_int_10(int x) { return x/10; }
  inline int ordena_digitos(int x) { 
    std::stringstream ss; ss<<x; 
    std::string s = ss.str();
    std::sort(s.begin(),s.end());
    return std::atoi(s.c_str());
  }
  static map<string,func_int> lista_funciones= { 
    {"pow_2",pow_2 }, 
    {"suma_5",suma_5},
    {"mod_5",mod_5 },
    {"mod_10",mod_10},
    {"div_int_5",div_int_5},
    {"div_int_10",div_int_10},
    {"ordena_digitos",ordena_digitos}
  };
  
  
  
//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> 
  
  list<set<int> > readLS(json &data, std::string name) { 
    list<set<int> > LS;
    json jLS = data[name];
    for(auto p = jLS.begin(); p!=jLS.end(); p++)
      LS.push_back(*p);
    return LS;
  }
  
  void writeLS(json &data, std::string name, list<set<int> > &LS) { 
    json &jLS = data[name];
    for(auto &S : LS)
      jLS.push_back(S);
  }
  
  typedef void (*filter_sets_t)(list<set<int>> &LS_IN,
                                int (*func)(int),list<set<int> > &LS_OUT);
  class eval_filter_sets_t : public eval_base_t {
  public:
    filter_sets_t F;
    eval_filter_sets_t() { dumptests=0; F=NULL; ejerc=3; testfile="./filter_sets.json"; }
    void run_case(json &data,json &outuser) {
      string fname = data["fname"];
      list<set<int> > LS_IN = readLS(data,"LS_IN"), LS_OUT;
      F(LS_IN,lista_funciones[fname],LS_OUT);
      writeLS(outuser,"LS_OUT",LS_OUT);
    }
    
    int check_case(json &datain,
                   json &outref,json &outuser) {
      return outref==outuser;
    }
    
    void generate_case(randomg_t &rnd,json &datain) {
      list<set<int> > LS(3+rnd.rand()%5);
      for (auto &S: LS) {
        // int Nelems = 3+rnd.rand()%8;
        for (int k=0; k<10; k++) S.insert(rnd.rand()%25);
      }
      writeLS(datain,"LS_IN",LS);
      auto it = lista_funciones.begin();
      advance(it,rnd.rand()%lista_funciones.size());
      datain["fname"] = it->first;
    }
  };
  
//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> 

  
  typedef int (*distancia_t)(map<int,list<int> >& G, int x, int y);
  class eval_distancia_t: public eval_base_t {
  public:
    distancia_t F;
    eval_distancia_t() { dumptests=0; F=NULL; testfile="./distancia.json"; }
    void run_case(json &data,json &outuser){
      auto G = str2graph<list<int>>(data["G"]);
      int x = data["x"], y = data["y"];
      int ret = F( G, x, y );
      outuser["ret"] = ret;
    }

    int check_case(json &datain, json &outref, json &outuser){
      return outref==outuser;
    }
    
    void generate_case(randomg_t &rnd,json &datain){
      auto lbl_gen = [&rnd](){return rnd.rand()%100;}; // para generar las etiquetas
      auto st_gen = [&rnd](int x){return rnd.rand()%x;}; // para generar los arcos
      auto G = make_random_graph<list<int>>(rnd.rand()%5+5,.5,lbl_gen,st_gen);
      datain["G"] = graph2str(G);
      int nnodes = G.size(); 
      auto it1 = G.begin(); advance(it1, rnd.rand()%nnodes); datain["x"] = it1->first;
      auto it2 = G.begin(); advance(it2, rnd.rand()%nnodes); datain["y"] = it2->first;
    }
  };
  

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> 
  
  
  typedef void (*suma_en_la_hoja_t)(tree<int>&T);
  class eval_suma_en_la_hoja_t : public eval_base_t {
  public:
    suma_en_la_hoja_t F;
    eval_suma_en_la_hoja_t() { dumptests=0; F=NULL; testfile="./suma_en_la_hoja.json"; }
    void run_case(json &data,json &outuser){
      string sT = data["T"];
      auto T = aed::lisp2tree<int>(sT);
      F(T);
      outuser["ret"] = lisp_print(T);
    }

    int check_case(json &datain, json &outref, json &outuser){
      return outref==outuser;
    }
    
    void generate_case(randomg_t &rnd,json &datain){
      auto lbl_gen = [&rnd](){return rnd.rand()%10+1;};
      auto st_gen = [&rnd](int x){return rnd.rand()%x;};
      auto T = make_random_tree<int>(rnd.rand()%25+15,8,lbl_gen,st_gen);
      datain["T"] = lisp_print(T);
    }
  };
  
  
//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

  using Eval = eval_t<eval_filter_sets_t,filter_sets_t,
                      eval_distancia_t,distancia_t,
                      eval_suma_en_la_hoja_t,suma_en_la_hoja_t>;
}

#endif
