#define USECHRONO
#include "eval.hpp"
#include <cassert>
#include <climits>
#include <cstdlib>
#include <stack>

using namespace aed;
using namespace std;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void transpose(vector<list<int> > &M,vector<list<int> > &Mt) {
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void homogeniza(list<int>& C, int hmin, int hmax) {
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
void bool_opers(list<int> &Lxor, list<int> &Land, 
                list<int> &L1, list<int> &L2) {
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
int main() {
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0;

  ev.eval<1>(transpose,vrbs);
  // h1 = ev.evalr<1>(transpose,seed,vrbs);
  
  // ev.eval<2>(homogeniza,vrbs);
  // h2 = ev.evalr<2>(homogeniza,seed,vrbs);
  
  // ev.eval<3>(bool_opers,vrbs);
  // h3 = ev.evalr<3>(bool_opers,seed,vrbs);

  // Debe dar para S=123 -> H1=028 H2=361 H3=840
  // printf("S=%03d -> H1=%03d H2=%03d H3=%03d\n",
  //        seed,h1,h2,h3);
  
  return 0;
}
