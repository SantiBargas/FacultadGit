#define USECHRONO
#include <cassert>
#include <climits>
#include <cstdlib>
#include <stack>
#include <map>
#include <numeric>
#include "eval.hpp"

using namespace aed;
using namespace std;

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

int max_sublist_m(list<int> &L, int m){
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

void remove_max_sibling(tree<int>&T, tree<int>::iterator it){
  // COMPLETAR...
}

void remove_max_sibling(tree<int>&T){
  // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

list<int> max_siblings_sum(tree<int>&T, tree<int>::iterator it) {
  return {}; // COMPLETAR...
}

list<int> max_siblings_sum(tree<int>&T) {
  return {}; // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

int max_valid_path(map<int,set<int>>& G, bool (*pred)(int), int node, int len, set<int> visited) {
  return 0; // COMPLETAR...
}

int max_valid_path(map<int,set<int>>& G, bool (*pred)(int)){
  return 0; // COMPLETAR...
}

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>

int main() {
  
  Eval ev;
  int vrbs = 0;
  int seed = 123;
  int h1=0,h2=0,h3=0,h4=0;
  
  cout << "seed: 123" << endl;
  do {
    ev.eval<1>(max_sublist_m,vrbs);
    h1 = ev.evalr<1>(max_sublist_m,seed,vrbs);
    
    ev.eval<2>(remove_max_sibling,vrbs);
    h2 = ev.evalr<2>(remove_max_sibling,seed,vrbs);
    
    ev.eval<3>(max_siblings_sum,vrbs);
    h3 = ev.evalr<3>(max_siblings_sum,seed,vrbs);
    
    ev.eval<4>(max_valid_path,vrbs);
    h4 = ev.evalr<4>(max_valid_path,seed,vrbs);
    
    printf("S=%03d -> H1=%03d H2=%03d H3=%03d H4=%03d\n",
           seed,h1,h2,h3,h4);
    
    cout << endl << "Siguiente seed: ";
  } while (cin>>seed);
  return 0;
  
}
