#ifndef EVAL_HPP
#define EVAL_HPP
#include "aedtools/evalbase.hpp"
#include "aedtools/lisp.hpp"
#include "aedtools/str_convs.hpp"
#include "aedtools/make_random.hpp"

namespace aed {

  
  typedef bool (*pred_int)(int);
  inline bool es_par(int x) { return x%2 == 0; }
  inline bool es_impar(int x) { return x%2 == 1; }
  // considerando que el generador genera ints entre 0 y 100
  inline bool es_menor_a_10(int x) { return x<10; }
  inline bool es_capicua(int x) { return x<10 || x/10==x%10; }
  inline bool es_primo(int x) {
    static set<int> primos =  {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101};
    return primos.count(x)!=0;
  }
  inline bool es_compuesto(int x) { return !es_primo(x); }
  inline bool es_fibonacci(int x) {
    static set<int> primos =  {0,1,2,3,5,8,13,21,34,55,89,144};
    return primos.count(x)==0;
  }
  static map<string,pred_int > lista_predicados = { 
    {"es_par",es_par }, 
    {"es_impar",es_impar},
    {"es_primo",es_primo},
    {"es_compuesto",es_compuesto},
    {"es_capicua",es_capicua},
    {"es_menor_a_10",es_menor_a_10},
    {"es_fibonacci",es_fibonacci} };
  
  
  
//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> max_sublist_m
  
  
  typedef int (*max_sublist_m_t)(list<int>&L, int m);
  class eval_max_sublist_m_t : public eval_base_t {
  public:
    max_sublist_m_t F;
    eval_max_sublist_m_t() { dumptests=0; F=NULL; testfile="./max_sublist_m.json"; }
    void run_case(json &data,json &outuser) {
      int m = data["m"];
      vector<int> Lv = data["L"];
      list<int> L;
      for (size_t j=0; j<Lv.size(); j++){
        L.push_back(Lv[j]);
      }
      outuser["ret"] = F(L,m);
    }
    
    int check_case(json &datain,
                   json &outref,json &outuser) {
      return outref==outuser;
    }
    
    void generate_case(randomg_t &rnd,json &datain) {
      int n=2+rnd.rand()%10,m=1+rnd.rand()%(n-1);
      datain["m"] = m;
      vector<int> Lv;
      for (int j=0; j<n; j++){
        Lv.push_back(rnd.rand()%(40)-20);
      }
      datain["L"] = Lv;
    }
  };
  
  template<typename T>
  void string2list(const string &str, list<T> &l) {
    stringstream ss (str); T aux;
    while (ss>>aux) l.push_back(aux);
  }
  template<typename T>
  string list2string(const list<T> &l) {
    stringstream ss; bool first = true;
    for(const auto &x:l) {
      if (!first) ss << " "; 
      ss << x; first=false; 
    }
    return ss.str();
  }
  
  
//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> remove_max_sibling

  
  typedef void (*remove_max_sibling_t)(tree<int>&);
  class eval_remove_max_sibling_t : public eval_base_t {
  public:
    remove_max_sibling_t F;
    eval_remove_max_sibling_t() { dumptests=0; F=NULL; testfile="./remove_max_sibling.json"; }
    void run_case(json &data,json &outuser){
      string sT = data["T"];
      tree<int> T;
      lisp2tree(sT,T);
      F(T);
      outuser["T"] = lisp_print(T);
    }

    int check_case(json &datain, json &outref, json &outuser){
      return outref==outuser;
    }
    
    int fix_ages(tree<int> T, tree<int>::iterator it, randomg_t &rnd) {
      int max_age = 0;
      for(auto c=it.lchild();c!=T.end();++c) {
        int cmax = fix_ages(T,c,rnd);
        *c += cmax;
        max_age = max(max_age,*c);
      }
      return max_age + rnd.rand()%10;
    }
    
    void generate_case(randomg_t &rnd,json &datain){
      auto lbl_gen = [&rnd](){return rnd.rand()%10+1;};
      auto st_gen = [&rnd](int x){return rnd.rand()%x;};
      auto T = make_random_tree<int>(rnd.rand()%25+15,8,lbl_gen,st_gen);
      *T.begin() += fix_ages(T,T.begin(),rnd);
      datain["T"] = lisp_print(T);
    }
  };
  

//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> max_siblings_sum
  
  
  typedef list<int> (*max_siblings_sum_t)(tree<int>&);
  class eval_max_siblings_sum_t : public eval_base_t {
  public:
    max_siblings_sum_t F;
    eval_max_siblings_sum_t() { dumptests=0; F=NULL; testfile="./max_siblings_sum.json"; }
    void run_case(json &data,json &outuser){
      string sT = data["T"];
      auto T = aed::lisp2tree<int>(sT);
      outuser["L"] = F(T);
    }

    int check_case(json &datain, json &outref, json &outuser){
      return outref==outuser;
    }
    
    void generate_case(randomg_t &rnd,json &datain){
      auto lbl_gen = [&rnd](){return rnd.rand()%100;};
      auto st_gen = [&rnd](int x){return rnd.rand()%x;};
      auto T = make_random_tree<int>(rnd.rand()%25+15,8,lbl_gen,st_gen);
      datain["T"] = lisp_print(T);
    }
  };
  
  
  
//---:---<*>---:---<*>---:---<*>---:---<*>---:---<*> max_valid_path
  
  
  typedef int (*max_valid_path_t)(map<int,set<int>>& G, bool (*pred)(int));
  class eval_max_valid_path_t : public eval_base_t {
  public:
    max_valid_path_t F;
    eval_max_valid_path_t() { dumptests=0; F=NULL; testfile="./max_valid_path.json"; }
    void run_case(json &data,json &outuser){
      auto G = str2graph<set<int>>(data["G"]);
      auto pred = lista_predicados[data["pred"]];
      int ret = F( G, pred );
      outuser["ret"] = ret;
    }

    int check_case(json &datain, json &outref, json &outuser){
      return outref==outuser;
    }
    
    void generate_case(randomg_t &rnd,json &datain){
      auto lbl_gen = [&rnd](){return rnd.rand()%100;}; // para generar las etiquetas
      auto st_gen = [&rnd](int x){return rnd.rand()%x;}; // para generar los arcos
      auto G = make_random_graph<set<int>>(rnd.rand()%5+5,.5,lbl_gen,st_gen);
      datain["G"] = graph2str(G);
      auto it = lista_predicados.begin();
      advance(it,rnd.rand()%lista_predicados.size());
      datain["pred"] = it->first;
    }
  };
  
  //---:---<*>---:---<*>---:---<*>---:---<*>---:---<*>
  using Eval = eval_t<eval_max_sublist_m_t,max_sublist_m_t,
                      eval_remove_max_sibling_t,remove_max_sibling_t,
                      eval_max_siblings_sum_t,max_siblings_sum_t,
                      eval_max_valid_path_t,max_valid_path_t>;
}
#undef CSTR

#endif
