%% Datos usados para resolver placa por elementos finitos
%Constantes el�sticas
E = 1;
po = 1/3;
%
%Datos de geometr�a
aNum = 1;
bNum = 20;
cNum = 20;
PNum = 1;
%Datos de la malla de EF
hMaxEF = aNum/20;
%Datos de los gr�ficos
nDivLinHor = 1000;
nDivLinVer = 1000;

%% Llamado a la funci�n creada con PDETool
%Hay que exportar manualmente la malla y los resultados.
%f_SolPDEa10c4
%f_SolPDEa20c4
%f_SolPDEa10c10
%
%Coordenadas de los nodos
%m_Coord = p;
% Se recupera los resultados de desplazamiento.
%uPDE = u(1:end/2);
%vPDE = u(end/2+1:end);
%Devuelve los gradientes en el centro del elemento.
%[uPDEx,uPDEy] = pdegrad(m_Coord,t,uPDE);
%[vPDEx,vPDEy] = pdegrad(m_Coord,t,vPDE);
%Devuelve el gradiente en los nodos de los elementos.
%uPDEx = pdeprtni(m_Coord,t,uPDEx);
%uPDEy = pdeprtni(m_Coord,t,uPDEy);
%vPDEx = pdeprtni(m_Coord,t,vPDEx);
%vPDEy = pdeprtni(m_Coord,t,vPDEy);

%% Se genera por l�nea de comando el problema
o_Resu = f_PlacaAgujPDE(aNum,bNum,cNum,PNum,E,po,hMaxEF);
%Resultados de desplazamiento
uPDE = o_Resu.NodalSolution(:,1);
vPDE = o_Resu.NodalSolution(:,2);
%Gradientes nodales
uPDEx = o_Resu.XGradients(:,1);
vPDEx = o_Resu.XGradients(:,2);
uPDEy = o_Resu.YGradients(:,1);
vPDEy = o_Resu.YGradients(:,2);
%Malla
m_Coord = o_Resu.Mesh.Nodes;

%% Tensiones calculadas a partir del resultado del PDE
%Deformaciones del PDE.
m_DefPDE = [uPDEx';vPDEy';uPDEy'+vPDEx'];
%Tensor tangente constitutivo (deformaci�n plana).
%m_C  = E/(1+po)/(1-2*po)*[1-po,po,0;po,1-po,0;0,0,(1-2*po)/2];
%Tensor tangente constitutivo (tensi�n plana).
m_C  = E/(1-po^2)*[1,po,0;po,1,0;0,0,(1-po)/2];
%Tensiones del PDE.
m_TensPDE = m_C*m_DefPDE;

%% Definici�n de funciones de interpolaci�n
%f_TensPDExx = TriScatteredInterp(p(1,:)',p(2,:)',m_TensPDE(1,:)');
o_TensPDExx = scatteredInterpolant(m_Coord(1,:)',m_Coord(2,:)',m_TensPDE(1,:)');
o_TensPDEyy = scatteredInterpolant(m_Coord(1,:)',m_Coord(2,:)',m_TensPDE(2,:)');
o_TensPDExy = scatteredInterpolant(m_Coord(1,:)',m_Coord(2,:)',m_TensPDE(3,:)');

%% Comparaci�n de resultados de la soluci�n exacta y num�rica
% L�nea horizontal
m_X = aNum:(bNum-aNum)/nDivLinHor:bNum;
m_Y = zeros(size(m_X));
%Para evaluaci�n de las tensiones
m_R = sqrt(bsxfun(@plus,m_X.^2,m_Y.^2));
m_Theta = bsxfun(@atan2,m_Y,m_X);
%
figure(10)
plot(m_X,f_Sx(m_R,m_Theta),m_X,o_TensPDExx(m_X,m_Y),...
   m_X,f_Sy(m_R,m_Theta),m_X,o_TensPDEyy(m_X,m_Y),...
   m_X,f_Sxy(m_R,m_Theta),m_X,o_TensPDExy(m_X,m_Y))
grid on
title('L�nea horizontal')
legend({'Sol. Anal�tica \sigma_{x}','Sol. MEF \sigma_{x}',...
   'Sol. Anal�tica \sigma_{y}','Sol. MEF \sigma_{y}',...
   'Sol. Anal�tica \sigma_{xy}','Sol. MEF \sigma_{xy}'},'Location','SouthEast')
%
% L�nea vertical
m_X = zeros(size(m_X));
m_Y = aNum:(cNum-aNum)/nDivLinVer:cNum;
%Para evaluaci�n de las tensiones
m_R = sqrt(bsxfun(@plus,m_X.^2,m_Y.^2));
m_Theta = bsxfun(@atan2,m_Y,m_X);
%
figure(11)
plot(m_Y,f_Sx(m_R,m_Theta),m_Y,o_TensPDExx(m_X,m_Y),...
   m_Y,f_Sy(m_R,m_Theta),m_Y,o_TensPDEyy(m_X,m_Y),...
   m_Y,f_Sxy(m_R,m_Theta),m_Y,o_TensPDExy(m_X,m_Y))
grid on
title('L�nea vertical')
legend({'Sol. Anal�tica \sigma_{x}','Sol. MEF \sigma_{x}',...
   'Sol. Anal�tica \sigma_{y}','Sol. MEF \sigma_{y}',...
   'Sol. Anal�tica \sigma_{xy}','Sol. MEF \sigma_{xy}'})