%% Ploteo de la norma del vector tensi�n en direcci�n de la normal al plano donde act�a.
p = -2;
alfa = 3;

%% Versi�n sin vectorizar
%f_T = @(theta)norm([p,alfa;alfa,p]*[cos(theta);sin(theta)]);

%% Versi�n vectorizada
f_T = @(m_theta)vecnorm([p,alfa;alfa,p]*[cos(m_theta.');sin(m_theta.')])';

%%
ezpolar(f_T)